# 第六章 自然语言处理 (NLP)

    Markdown Revision 1;
    Date: 2018/10/29
    Editor: 盛泳潘-电子科技大学
    Contact: shengyp2011@163.com


## 概述篇

不同于传问题。**定向循环结构如下图所示**：

![](../img/ch6/figure_6.1_1.jpg)
### 6.2 RNNs典型特点？


## 技术篇


